document.addEventListener("DOMContentLoaded", function () {
    const bookingForm = document.querySelector(".booking-form");
  
    bookingForm.addEventListener("submit", function (e) {
      e.preventDefault(); // Prevent page reload
  
      // Collect form values
      const service = document.getElementById("service").value;
      const date = document.getElementById("date").value;
      const time = document.getElementById("time").value;
      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const phone = document.getElementById("phone").value.trim();
  
      // Validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const phoneRegex = /^[0-9]{10}$/;
      const today = new Date().toISOString().split("T")[0];
  
      if (!service || !date || !time || !name || !email || !phone) {
        Swal.fire("Incomplete Form", "Please fill in all the required fields.", "warning");
        return;
      }
  
      if (date < today) {
        Swal.fire("Invalid Date", "Please select a valid future date.", "error");
        return;
      }
  
      if (!emailRegex.test(email)) {
        Swal.fire("Invalid Email", "Please enter a valid email address.", "error");
        return;
      }
  
      if (!phoneRegex.test(phone)) {
        Swal.fire("Invalid Phone", "Please enter a valid 10-digit phone number.", "error");
        return;
      }
  
      // If all validations pass
      const bookingData = {
        service,
        date,
        time,
        name,
        email,
        phone,
      };
  
      console.log("Booking Submitted:", bookingData);
      localStorage.setItem("latestBooking", JSON.stringify(bookingData));
      Swal.fire({
        title: `Thank you, ${name}!`,
        text: `Your ${service} appointment has been booked for ${date} at ${time}.`,
        icon: "success",
        confirmButtonText: "OK"
      });
  
      bookingForm.reset();
    });
  });
  